package com.learnnotes.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.learnnotes.app.data.model.ChatMessage
import com.learnnotes.app.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel(private val repository: ChatRepository) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    private val conversationHistory = mutableListOf<Pair<String, String>>()
    
    fun sendMessage(message: String) {
        if (message.isBlank()) return
        
        val userMessage = ChatMessage(
            message = message,
            isUser = true
        )
        _messages.value = _messages.value + userMessage
        conversationHistory.add("user" to message)
        
        _isLoading.value = true
        
        viewModelScope.launch {
            val result = repository.sendMessage(message, conversationHistory)
            if (result.isSuccess) {
                val response = result.getOrNull() ?: "Sorry, I couldn't generate a response."
                val aiMessage = ChatMessage(
                    message = response,
                    isUser = false
                )
                _messages.value = _messages.value + aiMessage
                conversationHistory.add("assistant" to response)
            } else {
                val error = result.exceptionOrNull()
                val errorMessage = ChatMessage(
                    message = "Error: ${error?.message ?: "Unknown error"}",
                    isUser = false
                )
                _messages.value = _messages.value + errorMessage
            }
            _isLoading.value = false
        }
    }
    
    fun clearChat() {
        _messages.value = emptyList()
        conversationHistory.clear()
    }
}

class ChatViewModelFactory(private val repository: ChatRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

