package com.learnnotes.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.learnnotes.app.data.model.Flashcard
import com.learnnotes.app.data.repository.FlashcardRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FlashcardViewModel(private val repository: FlashcardRepository) : ViewModel() {
    val flashcards: StateFlow<List<Flashcard>> = repository.getAllFlashcards()
    
    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()
    
    private val _isFlipped = MutableStateFlow(false)
    val isFlipped: StateFlow<Boolean> = _isFlipped.asStateFlow()
    
    private val _uiState = MutableStateFlow<FlashcardUiState>(FlashcardUiState())
    val uiState: StateFlow<FlashcardUiState> = _uiState.asStateFlow()
    
    fun insertFlashcard(flashcard: Flashcard) {
        viewModelScope.launch {
            repository.insertFlashcard(flashcard)
        }
    }
    
    fun updateFlashcard(flashcard: Flashcard) {
        viewModelScope.launch {
            repository.updateFlashcard(flashcard)
        }
    }
    
    fun deleteFlashcard(flashcard: Flashcard) {
        viewModelScope.launch {
            repository.deleteFlashcard(flashcard)
        }
    }
    
    fun nextCard(totalCards: Int) {
        if (totalCards > 0) {
            _currentIndex.value = (_currentIndex.value + 1) % totalCards
            _isFlipped.value = false
        }
    }
    
    fun previousCard(totalCards: Int) {
        if (totalCards > 0) {
            _currentIndex.value = (_currentIndex.value - 1 + totalCards) % totalCards
            _isFlipped.value = false
        }
    }
    
    fun flipCard() {
        _isFlipped.value = !_isFlipped.value
    }
    
    fun showAddFlashcardDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showAddDialog = show)
    }
}

data class FlashcardUiState(
    val showAddDialog: Boolean = false
)

class FlashcardViewModelFactory(private val repository: FlashcardRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FlashcardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FlashcardViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

