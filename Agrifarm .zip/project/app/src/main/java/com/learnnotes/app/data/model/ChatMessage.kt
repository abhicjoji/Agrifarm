package com.learnnotes.app.data.model

data class ChatMessage(
    val id: String = System.currentTimeMillis().toString(),
    val message: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

