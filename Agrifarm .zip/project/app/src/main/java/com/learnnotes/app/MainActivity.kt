package com.learnnotes.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnnotes.app.data.database.AppDatabase
import com.learnnotes.app.data.repository.ChatRepository
import com.learnnotes.app.data.repository.FlashcardRepository
import com.learnnotes.app.data.repository.NoteRepository
import com.learnnotes.app.ui.navigation.MainNavigation
import com.learnnotes.app.ui.theme.LearnNotesTheme
import com.learnnotes.app.ui.viewmodel.ChatViewModel
import com.learnnotes.app.ui.viewmodel.ChatViewModelFactory
import com.learnnotes.app.ui.viewmodel.FlashcardViewModel
import com.learnnotes.app.ui.viewmodel.FlashcardViewModelFactory
import com.learnnotes.app.ui.viewmodel.NoteViewModel
import com.learnnotes.app.ui.viewmodel.NoteViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize database and repositories
        val database = AppDatabase.getDatabase(applicationContext)
        val noteRepository = NoteRepository(database.noteDao())
        val flashcardRepository = FlashcardRepository(database.flashcardDao())
        val chatRepository = ChatRepository()
        
        setContent {
            LearnNotesTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val noteViewModel: NoteViewModel = viewModel(
                        factory = NoteViewModelFactory(noteRepository)
                    )
                    val chatViewModel: ChatViewModel = viewModel(
                        factory = ChatViewModelFactory(chatRepository)
                    )
                    val flashcardViewModel: FlashcardViewModel = viewModel(
                        factory = FlashcardViewModelFactory(flashcardRepository)
                    )
                    
                    MainNavigation(
                        noteViewModel = noteViewModel,
                        chatViewModel = chatViewModel,
                        flashcardViewModel = flashcardViewModel
                    )
                }
            }
        }
    }
}

