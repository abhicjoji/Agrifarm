package com.learnnotes.app.data.api

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface ChatApiService {
    @POST("chat/completions")
    suspend fun sendMessage(@Body request: ChatRequest): Response<ChatResponse>
}

data class ChatRequest(
    val model: String = "gpt-3.5-turbo",
    val messages: List<ChatMessageRequest>,
    val max_tokens: Int = 500,
    val temperature: Double = 0.7
)

data class ChatMessageRequest(
    val role: String,
    val content: String
)

data class ChatResponse(
    val choices: List<Choice>
)

data class Choice(
    val message: Message
)

data class Message(
    val role: String,
    val content: String
)

