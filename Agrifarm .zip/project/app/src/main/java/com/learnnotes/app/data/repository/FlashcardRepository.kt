package com.learnnotes.app.data.repository

import com.learnnotes.app.data.dao.FlashcardDao
import com.learnnotes.app.data.model.Flashcard
import kotlinx.coroutines.flow.Flow

class FlashcardRepository(private val flashcardDao: FlashcardDao) {
    fun getAllFlashcards(): Flow<List<Flashcard>> = flashcardDao.getAllFlashcards()
    
    suspend fun getFlashcardById(id: Long): Flashcard? = flashcardDao.getFlashcardById(id)
    
    suspend fun insertFlashcard(flashcard: Flashcard): Long = flashcardDao.insertFlashcard(flashcard)
    
    suspend fun updateFlashcard(flashcard: Flashcard) = flashcardDao.updateFlashcard(flashcard)
    
    suspend fun deleteFlashcard(flashcard: Flashcard) = flashcardDao.deleteFlashcard(flashcard)
    
    suspend fun deleteFlashcardById(id: Long) = flashcardDao.deleteFlashcardById(id)
}

