package com.learnnotes.app.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.learnnotes.app.data.dao.FlashcardDao
import com.learnnotes.app.data.dao.NoteDao
import com.learnnotes.app.data.model.Flashcard
import com.learnnotes.app.data.model.Note

@Database(
    entities = [Note::class, Flashcard::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun flashcardDao(): FlashcardDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "learnnotes_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

