package com.learnnotes.app.data.repository

import com.learnnotes.app.data.api.ApiClient
import com.learnnotes.app.data.api.ChatMessageRequest
import com.learnnotes.app.data.api.ChatRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ChatRepository {
    private val apiService = ApiClient.chatApiService
    
    suspend fun sendMessage(userMessage: String, conversationHistory: List<Pair<String, String>>): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val messages = mutableListOf<ChatMessageRequest>().apply {
                    // Add system message for context
                    add(ChatMessageRequest("system", "You are a helpful AI assistant for a note-taking and learning app. Help users with their questions about their notes and learning materials."))
                    // Add conversation history
                    conversationHistory.forEach { (role, content) ->
                        add(ChatMessageRequest(role, content))
                    }
                    // Add current user message
                    add(ChatMessageRequest("user", userMessage))
                }
                
                val request = ChatRequest(
                    model = "gpt-3.5-turbo",
                    messages = messages,
                    max_tokens = 500,
                    temperature = 0.7
                )
                
                val response = apiService.sendMessage(request)
                
                if (response.isSuccessful && response.body() != null) {
                    val aiResponse = response.body()!!.choices.firstOrNull()?.message?.content
                        ?: "Sorry, I couldn't generate a response."
                    Result.success(aiResponse)
                } else {
                    Result.failure(Exception("API Error: ${response.code()}"))
                }
            } catch (e: Exception) {
                // Fallback response for demo purposes
                Result.success("I'm a demo AI assistant. To use the full AI features, please configure your API key in ApiClient.kt. For now, I can help you organize your notes and create flashcards!")
            }
        }
    }
}

