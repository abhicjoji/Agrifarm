package com.learnnotes.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.learnnotes.app.data.model.Note
import com.learnnotes.app.data.repository.NoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NoteViewModel(private val repository: NoteRepository) : ViewModel() {
    val notes: StateFlow<List<Note>> = repository.getAllNotes()
    
    private val _uiState = MutableStateFlow<NoteUiState>(NoteUiState())
    val uiState: StateFlow<NoteUiState> = _uiState.asStateFlow()
    
    fun insertNote(note: Note) {
        viewModelScope.launch {
            repository.insertNote(note)
        }
    }
    
    fun updateNote(note: Note) {
        viewModelScope.launch {
            repository.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
        }
    }
    
    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }
    
    fun setSelectedNote(note: Note?) {
        _uiState.value = _uiState.value.copy(selectedNote = note)
    }
    
    fun showAddNoteDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showAddDialog = show)
    }
    
    fun showEditNoteDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showEditDialog = show)
    }
}

data class NoteUiState(
    val selectedNote: Note? = null,
    val showAddDialog: Boolean = false,
    val showEditDialog: Boolean = false
)

class NoteViewModelFactory(private val repository: NoteRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NoteViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NoteViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

